# Topology lifecycle and idle resource baseline

Collected on 2026-10-23 in WSL2. Runtime checkout:
b2ebbc964041b30b66b8d089e2d157faea9f1595 (package version 1.7.0).

The coordinator used Python 3.12.3. All 40 trials and all 300 directional
connectivity probes succeeded. No trials were excluded. Each trial used a new
interpreter and its own compiler cache. The default info log level was used,
with packet capture disabled and no link impairments.

- environment.json: system, software, source hashes and exact settings.
- results.json: all trials, process CPU/memory snapshots and connectivity checks.
- summary.md: medians grouped by switch count and compiler-cache state.
- collection.json: collection times, validation totals and lifecycle ranges.
- n*/: per-trial result, topology names, worker log and BMv2 logs.
- tools/benchmark.py and examples/quick_start/quick_start.p4: measured harness
  and P4 source snapshots. Compiler artifacts are kept in the local run directory.
- SHA256SUMS: checksums for every other file in this archive.

Run the harness from a p4net repository checkout with the recorded native tools
and Python dependencies installed. The included snapshots identify the exact
measurement code. CPU uses 100% per logical CPU. Memory covers the Python worker
and BMv2 processes during the idle sampling window, excluding compiler processes
and kernel networking memory. PSS apportions shared pages; RSS sums can count
shared pages repeatedly. The figures are snapshot means, not lifecycle peaks.
